package com.lifegreen.apicliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiclienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
